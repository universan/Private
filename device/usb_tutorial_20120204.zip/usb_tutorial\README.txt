This is the source code package for AVR ATtiny USB Tutorial by Joonas Pihlajamaa, published at Code and Life blog, http://codeandlife.com:

http://codeandlife.com/2012/01/22/avr-attiny-usb-tutorial-part-1/
http://codeandlife.com/2012/01/25/avr-attiny-usb-tutorial-part-2/
http://codeandlife.com/2012/01/29/avr-attiny-usb-tutorial-part-3/
http://codeandlife.com/2012/02/04/avr-attiny-usb-tutorial-part-4/
 

The subfolders contain parts of libusb-win32 available at http://sourceforge.net/apps/trac/libusb-win32/wiki and V-USB library available at http://www.obdev.at/avrusb/ and their contents are copyrighted by their respective authors. My productions in the root folder are published under GNU GPL v3 (see License.txt).

I hope you have fun with this project!

- Joonas Pihlajamaa