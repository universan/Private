const createCRUDController = require('@/controllers/middlewaresControllers/createCRUDController');
module.exports = createCRUDController('Order');
